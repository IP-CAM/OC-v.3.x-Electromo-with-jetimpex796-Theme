<?php
/**
 * @version		$Id: not_found.php 4989 2017-06-22 09:22:42Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']		= 'Seite nicht gefunden';

// Text
$_['text_not_found']	= 'Die angeforderte Seite konnte leider nicht gefunden werden.<br />Sollte das Problem weiterhin bestehen, bitte die Shopverwaltung davon informieren (siehe Kontakt) - vielen Dank.';