<?php
/**
 * @version		$Id: basic.php 4990 2017-06-22 12:54:00Z mic $
 * @package		Language Translation German Backend
 * @author		mic - https://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['heading_title']		= 'Einfaches Captcha';

// Text
$_['text_extension']	= 'Erweiterungen';
$_['text_success']		= 'Datensatz erfolgreich bearbeitet';
$_['text_edit']			= 'Bearbeiten';

// Entry
$_['entry_status']		= 'Status';

// Error
$_['error_permission']	= 'Keine Berechtigung für diese Aktion';