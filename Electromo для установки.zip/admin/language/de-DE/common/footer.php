<?php
/**
 * @version		$Id: footer.php 4990 2017-06-22 12:54:00Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */
// Text
$_['text_footer'] = '<a href="http://www.opencart.com" target="_blank">OpenCart</a> &copy; 2009-' . date('Y') . ' Alle Rechte vorbehalten.<br />Dt. Übersetzung von &copy; <a href="https://osworx.net" target="_blank">OSWorX</a>';
$_['text_version']= 'Version %s';